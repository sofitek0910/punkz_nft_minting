$('main').css("padding-top", $("header").height());
$('.sp-menu a').click(function() {
    $(".menu-icon").click();
})
$(document).ready(function() {

    $('.menu-icon').on('click', function() {
        $('.menu-top').toggleClass("slide-in");
        $('.menu-bottom').toggleClass("slide-in");

        if ($(this).text() == "Menu") {
            $(this).text("Close");
            $("header").css("height", "100vh");
            $(".menu-bottom").css("top", "auto");
            $(".sp-menu").css("display", "block");
        } else {
            $(this).text("Menu");
            $("header").css("height", "auto");
            $(".menu-bottom").css("top", "-1000px");
            $(".sp-menu").css("display", "none");
        }
    });

});